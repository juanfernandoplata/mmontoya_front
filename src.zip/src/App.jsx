import React, { useEffect, createContext, useContext } from 'react';
import { useState, useRef } from 'react';

import axios from "axios";

import 'chart.js/auto'
import { Bar, Pie, getElementAtEvent } from 'react-chartjs-2';

import { BAR_STACKED_CLICKABLE } from './chartOpts';

import WhatsAppLogo from "./assets/WhatsApp.svg.webp"
import EmailIcon from "./assets/Email.svg"


const MONTH_NAMES = [ "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic" ]
const DAY_NAMES = [ "Lun", "Mar", "Mie", "Jue", "Vie", "Sab", "Dom" ]

const Ctx = createContext( null )


function MTsButton( { text, onClick, marginLeft = false } ){
    return <button
        style = {{
            height: "25px",
            marginLeft: marginLeft ? "7px" : "0",
            padding: "0 8px",
            fontSize: "medium",
            fontWeight: "bold"
        }}

        onClick = { onClick }
    >
        { text }
    </button>
}


function MTsChart(){
    const {
        mTs, setMTs,
        pTs, setPTs,
        // mTsData, setMTsData,
        pTsData, setPTsData,
        interList, setInterList,
        selInter, setSelInter
    } = useContext( Ctx )

    const chartRef = useRef( null )
    const [ data, setData ] = useState( { labels: [], datasets: [] } )
    const pTsDataIndex = useRef( null )
    const [ opts, setOpts ] = useState( BAR_STACKED_CLICKABLE( setMTs, setPTs, setData, setPTsData, pTsDataIndex ) )

    useEffect(
        () => {
            axios.get( "http://localhost:8000/interactions/count?year=2024" )
            .then( ( res ) => {
                const labels = res.data.datasets.map( ( e ) => e.label )
                const data = res.data.datasets.map(
                    ( e ) => e.data.reduce( ( acum, e ) => acum + e )
                )

                setData( res.data )
                setPTsData({
                    labels: labels,
                    datasets: [ { data: data } ]
                })

                axios.get( `http://localhost:8000/interactions?year=2024` )
                .then( ( res ) => {
                    setInterList( res.data )
                })
            })
        },
        []
    )

    const handleYearClick = () => {
        let qParams = `?year=${mTs.year}`
        axios.get( `http://localhost:8000/interactions/count${qParams}` )
        .then( ( res ) => {
            setData( res.data )
            setMTs( ( curr ) => ( { ...curr, month: null, week: null, day: null } ) )
            setPTs( ( curr ) => ( { ...curr, month: null, week: null, day: null } ) )

            const labels = res.data.datasets.map( ( e ) => e.label )
            const data = res.data.datasets.map(
                ( e ) => e.data.reduce( ( acum, e ) => acum + e )
            )

            pTsDataIndex.current = -1
            setPTsData({
                labels: labels,
                datasets: [ { data: data } ]
            })

            axios.get( `http://localhost:8000/interactions${qParams}` )
            .then( ( res ) => {
                setInterList( res.data )
                setSelInter( -1 )
            })
        })
    }

    const handleMonthClick = () => {
        let qParams = `?year=${mTs.year}&month=${mTs.month}`
        axios.get( `http://localhost:8000/interactions/count${qParams}` )
        .then( ( res ) => {
            setData( res.data )
            setMTs( ( curr ) => ( { ...curr, week: null, day: null } ) )
            setPTs( ( curr ) => ( { ...curr, week: null, day: null } ) )

            const labels = res.data.datasets.map( ( e ) => e.label )
            const data = res.data.datasets.map(
                ( e ) => e.data.reduce( ( acum, e ) => acum + e )
            )

            pTsDataIndex.current = -1
            setPTsData({
                labels: labels,
                datasets: [ { data: data } ]
            })

            axios.get( `http://localhost:8000/interactions${qParams}` )
            .then( ( res ) => {
                setInterList( res.data )
                setSelInter( -1 )
            })
        })
    }

    const handleWeekClick = () => {
        let qParams = `?year=${mTs.year}&month=${mTs.month}&week=${mTs.week}`
        axios.get( `http://localhost:8000/interactions/count${qParams}` )
        .then( ( res ) => {
            setData( res.data )
            setMTs( ( curr ) => ( { ...curr, day: null } ) )
            setPTs( ( curr ) => ( { ...curr, day: null } ) )

            const labels = res.data.datasets.map( ( e ) => e.label )
            const data = res.data.datasets.map(
                ( e ) => e.data.reduce( ( acum, e ) => acum + e )
            )

            pTsDataIndex.current = -1
            setPTsData({
                labels: labels,
                datasets: [ { data: data } ]
            })

            axios.get( `http://localhost:8000/interactions${qParams}` )
            .then( ( res ) => {
                setInterList( res.data )
                setSelInter( -1 )
            })
        })
    }

    const handleChartClick = ( e ) => {
        if( !opts.onHover ){ return }
        const element = getElementAtEvent( chartRef.current, e )
        if( !element.length ){ return }
        const { index } = element[ 0 ]

        let qParams = "?"
        if( mTs.week !== null ){
            setPTs( { ...mTs, day: index } )
            qParams += `year=${mTs.year}&month=${mTs.month}&week=${mTs.week}&day=${index}`
        }
        else if( mTs.month && mTs.week === null ){
            setMTs( ( curr ) => ( { ...curr, week: index } ) )
            setPTs( ( curr ) => ( { ...curr, week: index } ) )
            // setOpts( BAR_STACKED_NOT_CLICKABLE( setMTs, setPTs, setData, setPTsData, pTsDataIndex ) )
            qParams += `year=${mTs.year}&month=${mTs.month}&week=${index}`
        }
        else if( mTs.year && mTs.month === null ){
            setMTs( ( curr ) => ( { ...curr, month: index + 1 } ) )
            setPTs( ( curr ) => ( { ...curr, month: index + 1 } ) )
            qParams += `year=${mTs.year}&month=${index + 1}`
        }
        else{
            console.log( "ERROR: this condition should NEVER be true..." )
            // console.log( ts )
        }

        pTsDataIndex.current = -1
        axios.get( `http://localhost:8000/interactions/count${qParams}` )
        .then( ( res ) => {
            setData( res.data )

            axios.get( `http://localhost:8000/interactions${qParams}` )
            .then( ( res ) => {
                setInterList( res.data )
                setSelInter( -1 )
            })
        })
    }

    return <div
        style = {{
            width: "100%",
            height: "100%",

            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
        }}
    >
        <div
            style = {{
                display: "flex",
                flexDirection: "row",
                alignItems: "center",
            }}
        >
            <MTsButton
                text = { mTs.year }
                onClick = { handleYearClick }
            />
            { mTs.month !== null && <MTsButton
                text = { MONTH_NAMES[ mTs.month - 1 ] }
                marginLeft = { true }
                onClick = { handleMonthClick }
            />}
            { mTs.week !== null && <MTsButton
                text = { `S${ mTs.week + 1 }` }
                marginLeft = { true }
                onClick = { handleWeekClick }
            />}
        </div>
        <div
            style = {{
                width: "100%",
                height: "89%",
            }}
        >
            <Bar
                ref = { chartRef }
                data = { data }
                options = { opts }

                onClick = { handleChartClick }
            />
        </div>
    </div>
}


function LeftUpperFrame(){
    return <div
        style = {{
            width: "100%",
            height: "63%",

            padding: "15px",
            backgroundColor: "white",
            borderRadius: "5px",
            border: "1px solid #E2E9F3",
        }}
    >
        <MTsChart/>
    </div>
}


function LeftLowerFrame(){
    return <div
        style = {{
            width: "100%",
            height: "35%",

            padding: "15px",
            backgroundColor: "white",
            borderRadius: "5px",
            border: "1px solid #E2E9F3"
        }}
    ></div>
}


function LeftSide(){
    return <div
        style = {{
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",

            width: "70%",
            height: "100%",
        }}
    >
        <LeftUpperFrame/>
        <LeftLowerFrame/>
    </div>
}


function PTsPTag( { text, marginLeft = false } ){
    return <p
        style = {{
            height: "25px",
            margin: "0",
            marginLeft: marginLeft ? "7px" : "0",
            padding: "0 8px",

            border: "1px solid #E2E9F3",
            borderRadius: "5px",
            backgroundColor: "#F1F4F9",
            fontSize: "medium",
            fontWeight: "bold",
        }}
    >
        { text }
    </p>
}


function PTsChart(){
    const { pTs, pTsData } = useContext( Ctx )

    return <>
        <div
            style = {{
                width: "100%",
                height: "100%",

                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
            }}
        >
            <div
                style = {{
                    display: "flex",
                    flexDirection: "row",
                    alignItems: "center",
                }}
            >
                { pTs.month !== null && <PTsPTag
                    text = { MONTH_NAMES[ pTs.month - 1 ] }
                />}
                { pTs.week !== null && <PTsPTag
                    text = { `S${ pTs.week + 1 }` }
                    marginLeft = { true }
                />}
                { pTs.day !== null && <PTsPTag
                    text = { `${ DAY_NAMES[ pTs.day ] }` }
                    marginLeft = { true }
                />}
            </div>
            <div
                style = {{
                    width: "100%",
                    height: "86%",

                    padding: "0",
                }}
            >
                <Pie
                    data = { pTsData }
                    options = {{
                        responsive: true,
                        maintainAspectRatio: false,
                    
                        plugins: {
                            legend: {
                                position: "left"
                            }
                        }
                    }}
                />
            </div>
        </div>
    </>
}


function RightUpperFrame(){
    return <div
        style = {{
            width: "100%",
            height: "40%",

            padding: "15px",
            backgroundColor: "white",
            borderRadius: "5px",
            border: "1px solid #E2E9F3"
        }}
    >
        <PTsChart/>
    </div>
}


function Checker( { checked = false, handleCheckerClick } ){
    return <div
        className = "checker"

        onClick = { handleCheckerClick }

        style = {{
            position: "relative",

            width: "17px",
            height: "17px",

            marginRight: "7px",
            
            borderRadius: "50%",
            border: "1px solid E2E9F3",
            backgroundColor: "white"
        }}
    >
        <div
            style = {{
                position: "absolute",

                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                
                width: "9px",
                height: "9px",
                
                margin: "auto",
                
                borderRadius: "50%",
                border: "1px solid E2E9F3",
                backgroundColor: checked ? "#57f252" : "#f25252"
            }}
        />
    </div>
}


const BarType = { "CONTACT": 0, "DEPOSIT": 1, "ARRIVAL": 2 }

function InterBar( { i, barType, clientName, checked, handleCheckerClick } ){
    const BarBgCols = [ "#e3f0fa", "#fae3e3", "#faf2e3" ]

    const { setSelInter } = useContext( Ctx )

    return <div
        style = {{
            width: "100%",
            height: "50px",

            marginBottom: "7px",
            padding: "5px",

            borderRadius: "5px",
            border: "1px solid #E2E9F3",
            backgroundColor: BarBgCols[ BarType[ barType ] ]
        }}
    >
        <div
            style = {{
                width: "100%",
                height: "100%",

                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center"
            }}
        >
            <p
                className = "client-name"

                onClick = { () => setSelInter( i ) }

                style = {{
                    paddingLeft: "7px",

                    fontSize: "large",
                    fontWeight: "bold"
                }}
            >
                { clientName }
            </p>
            <Checker
                checked = { checked }
                handleCheckerClick = { handleCheckerClick }
            />
        </div>
    </div>
}


function InterBarCont( { interList, setInterList } ){
    const handleCheckerClick = ( i ) => {
        const client_vid = interList[ i ].client.vid
        const milestone_type = interList[ i ].interaction.milestone_type
        const inter_date = interList[ i ].interaction.inter_date

        const qArgs = `?client_vid=${client_vid}&milestone_type=${milestone_type}&inter_date=${inter_date}}`

        axios.post( `http://localhost:8000/interactions/checked/toogle${qArgs}` )
        .then( ( res ) => {
            setInterList( ( curr ) => {
                const aux = curr.slice()
                aux[ i ].interaction.checked = res.data.new_value
                
                return aux
            })
        })
    }

    return <div
        style = {{
            width: "100%",
            height: "100%"
        }}
    >
        { interList.map( ( e, i ) => (
            <InterBar
                key = { i }
                i = { i }
                barType = { e.interaction.milestone_type }
                clientName = { `${ e.client.name } ${ e.client.lastname }` }
                checked = { e.interaction.checked }
                handleCheckerClick = { () => handleCheckerClick( i ) }
            />
        ))}
        <div style = {{ height: "8px" }}/>
    </div>
}


function PTagPosAbs( { text, top, left, fontSize } ){
    return <p
        style = {{
            position: "absolute",
            top: top,
            left: left,

            width: "fit-content",

            margin: "0",
            padding: "0",

            fontSize: fontSize,
            fontWeight: "bold",

            // border: "1px solid red"
        }}
    >
        { text }
    </p>
}


function InterDetails( { interaction, handleClose } ){
    return <div
        style = {{
            position: "relative",

            width: "100%",
            height: "100%",

            overflow: "hidden"
        }}
    >
        <div
            className = "close-btn"

            onClick = { handleClose }

            style = {{
                position: "absolute",
                top: "0px",
                left: "309px",

                width: "22px",
                height: "22px",

                borderRadius: "50%",
                border: "1px solid #E2E9F3",

                backgroundColor: "#F1F4F9"
            }}
        >
            <PTagPosAbs
                text = "x"
                top = "-4px"
                left = "6px"
                fontSize = "medium"
            />
        </div>
        <PTagPosAbs
            text = { interaction.client.name }
            top = "-13px"
            left = "10px"
            fontSize = "xxx-large"
        />
        <PTagPosAbs
            text = { interaction.client.lastname }
            top = "47px"
            left = "10px"
            fontSize = "xx-large"
        />
        <img
            width = "30px"
            height = "30px"
            src = { WhatsAppLogo }

            style = {{
                position: "absolute",
                top: "107px",
                left: "10px",
            }}
        />
        <PTagPosAbs
            text = { interaction.client.phone }
            top = "107px"
            left = "50px"
            fontSize = "large"
        />
        <img
            width = "24px"
            height = "24px"
            src = { EmailIcon }

            style = {{
                position: "absolute",
                top: "145px",
                left: "13px",
            }}
        />
        <PTagPosAbs
            text = { interaction.client.email }
            top = "142px"
            left = "50px"
            fontSize = "large"
        />
        <PTagPosAbs
            text = "Comentarios"
            top = "182px"
            left = "10px"
            fontSize = "x-large"
        />
        <textarea
            style = {{
                position: "absolute",
                top: "227px",
                left: "10px",

                resize: "none",
                width: "94%",
                height: "55px",
            }}
        >
            { interaction.interaction.inter_desc }
        </textarea>
    </div>
}


function RightLowerFrame(){
    const {
        interList, setInterList,
        selInter, setSelInter
    } = useContext( Ctx )

    return <div
        style = {{
            width: "100%",
            height: "58%",

            overflow: "auto",

            padding: "15px",
            backgroundColor: "white",
            borderRadius: "5px",
            border: "1px solid #E2E9F3"
        }}
    >
        { selInter === -1 && <InterBarCont
            interList = { interList }
            setInterList = { setInterList }
        />}
        { selInter !== -1 && <InterDetails
            interaction = { interList[ selInter ] }

            handleClose = { () => setSelInter( -1 ) }
        />}
    </div>
}


function RightSide(){
    return <div
        style = {{
            width: "29%",
            height: "100%",

            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
        }}
    >
        <RightUpperFrame/>
        <RightLowerFrame/>
    </div>
}


function Dashboard(){
    const [ mTs, setMTs ] = useState( { year: 2024, month: null, week: null, day: null } )
    const [ pTs, setPTs ] = useState( { year: 2024, month: null, week: null, day: null } )
    // const [ mTsData, setMTsData ] = useState( null )
    const [ pTsData, setPTsData ] = useState( { labels: [], datasets: [] } )
    const [ interList, setInterList ] = useState( [] )
    const [ selInter, setSelInter ] = useState( -1 )

    return <Ctx.Provider
        value = {{
            mTs, setMTs,
            pTs, setPTs,
            // mTsData, setMTsData,
            pTsData, setPTsData,
            interList, setInterList,
            selInter, setSelInter
        }}
    >
        <div
            style = {{
                width: "100vw",
                height: "100vh",

                padding: "15px",
            }}
        >
            <div
                style = {{
                    width: "100%",
                    height: "100%",

                    display: "flex",
                    flexDirection: "row",
                    justifyContent: "space-between",
                }}
            >
                <LeftSide/>
                <RightSide/>
            </div>
        </div>
    </Ctx.Provider>
}


function App(){
    return <Dashboard/>
}


export default App